package com.module1.codes;

import org.testng.annotations.Test;

public class qatest001 {
  @Test
  public void f() {
	  System.out.println("qa test 001");
  }
}
