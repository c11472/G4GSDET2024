package Day2_JavaBasics;

public class AcessTestLibrary {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TestLibrary obj = new TestLibrary();

		int arr[] = {10,20,30,40,50};
		//TestLibrary obj = new TestLibrary();
		obj.testarr(arr);
		
		obj.Emp1Details("test user new");
		
		obj.Emp1Details("testuser2", 5656);
		
		obj.Emp1Details("trstt8", 675675, "QA");

	}

}
