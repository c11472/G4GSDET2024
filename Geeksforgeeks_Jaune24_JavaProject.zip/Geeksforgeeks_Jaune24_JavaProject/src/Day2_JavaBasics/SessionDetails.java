package Day2_JavaBasics;

import java.util.Scanner;

public class SessionDetails {
   // main block
    
	public static void main(String[] args) {
		
		SessionDetails a = new SessionDetails();
		sessiondetailsdemo();
		a.sessionName();
		test1();
		String result=a.emptestid();//9090
		System.out.println(result);

	}
	// method definition
  static void sessiondetailsdemo() {
		Scanner c = new Scanner(System.in);
		
		System.out.println("Enter Session id");
		int sessionid = c.nextInt();
		System.out.println("Session id is :" +sessionid );
		
	}
	// No return type
 	void sessionName() {
		System.out.println("The session name is SDET Lev 1");
	}
	
static void test1() {
		System.out.println("Sample");
	}

String emptestid() {
	String etestid = "9090";
	//System.out.println(etestid);
	return etestid;
		
}
}
