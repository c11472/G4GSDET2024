package Day2_JavaBasics;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		AccessBankDetails  obj = new AccessBankDetails ();
		obj.BankName();
		obj.BankCode();

	}

}
