package Day2_JavaBasics;

import java.util.Scanner;

class Testbase{
	void InpNumber() {
		Scanner c = new Scanner(System.in);
		int num = c.nextInt();
		System.out.println(num);
	}
}

class Testbase2 extends Testbase{
	void InpNumber() {
		System.out.println("test output");
		
	}
}

class Testbase3 extends Testbase2{
	void InpNumber() {
		System.out.println("test output2"); //Override 
		
	}
	
}
public class TestOverride1 extends Testbase3  {
	
	public static void main(String args[]) {
		//Testbase obj = new TestOverride1(); 
		
		Testbase2 obj1 = new TestOverride1();
		obj1.InpNumber();
		
		Testbase obj = new TestOverride1();
		obj1.InpNumber();
		
		Testbase obj3 = new Testbase(); // specific class obj
		obj3.InpNumber(); // not overriding
		
		
	}
	
	void InpNumber() {
		System.out.println("test output3"); //Override 

	}
	
}

