package Day2_JavaBasics;

public class DemoOverride {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		testoverride t1 = new testoverride();
		t1.emp1();
		
		
		
		

	}
	
	void emp1() {
		System.out.println("test1");

    }
	
	/*void emp1() {
		System.out.println("test2");

		
	}
	
	void emp1() {
		System.out.println("test3");

		
	}*/
	
}

class testoverride extends  DemoOverride {
	@Override
	void emp1() {
		System.out.println("this is day2 of Java"); 

    }
}
