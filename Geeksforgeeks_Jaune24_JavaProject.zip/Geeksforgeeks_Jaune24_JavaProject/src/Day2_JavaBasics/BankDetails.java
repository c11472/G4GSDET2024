package Day2_JavaBasics;

abstract class BankDetails {
	abstract void BankName(); 
	abstract void BankCode();

}
