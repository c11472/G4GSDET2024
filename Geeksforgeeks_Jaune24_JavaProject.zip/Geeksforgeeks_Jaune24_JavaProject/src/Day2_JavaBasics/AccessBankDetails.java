package Day2_JavaBasics;

public class AccessBankDetails  extends BankDetails{

	
	void BankName() {
		String bnm = "SBI";
		System.out.println(bnm);
		
	}

	
	void BankCode() {
		String bcode = "146678";
		System.out.println(bcode);

		
		
	}

}
