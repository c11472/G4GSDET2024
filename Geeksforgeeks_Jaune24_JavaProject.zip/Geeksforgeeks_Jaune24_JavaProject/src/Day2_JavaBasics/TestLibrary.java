package Day2_JavaBasics;

public class TestLibrary {
	
	   void Emp1Details(String ename) {
		   ename = "test1"; // op
		   System.out.println(ename);
		   
	   }
		
		String Emp1Details(String ename,int eid) {
		
			//System.out.println(ename + " " + eid);
			return ename;
			
		}
		
		void Emp1Details(String ename1, int eid1 , String dept1) {
			System.out.println(ename1 + " " + eid1 + " "+ dept1);
		}
		// returning  array 
	  void testarr(int brr[]) {
			System.out.println("Array as param");
			for(int i=0;i<=brr.length-1;i++) {
				System.out.println(brr[i]);
			}
			

	  }
}
