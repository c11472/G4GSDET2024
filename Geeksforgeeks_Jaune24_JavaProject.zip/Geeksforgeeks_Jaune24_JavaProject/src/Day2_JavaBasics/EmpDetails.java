package Day2_JavaBasics;

public class EmpDetails {
   public static void main(String[] args) {
		// TODO Auto-generated method stub
	   
	   int arr[] = {1,2,3,4,5}; // init array
	   int tt[] = {10,20,30};
		
		EmpDetails obj = new EmpDetails();
		String res=obj.Emp1Details("testuseremp", 1989);
		System.out.println(res);
		obj.Emp1Details("testemp2", 1234, "IT");
		obj.Emp1Details("Mishra");
		obj.testarr(tt);
		

	}
   
   void Emp1Details(String ename) {
	   ename = "test1"; // op
	   System.out.println(ename);
	   
   }
	
	String Emp1Details(String ename,int eid) {
	
		//System.out.println(ename + " " + eid);
		return ename;
		
	}
	
	void Emp1Details(String ename1, int eid1 , String dept1) {
		System.out.println(ename1 + " " + eid1 + " "+ dept1);
	}
	// returning  array 
  void testarr(int brr[]) {
		System.out.println("Array as param");
		for(int i=0;i<=brr.length-1;i++) {
			System.out.println(brr[i]);
		}
		
		
	}
	
	
}
