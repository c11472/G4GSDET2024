package Day2_JavaBasics;

	class Employee {
		String empnm;
		int empid;
		Employee(){
			empnm="testdata";
			empid = 1343;
		}
		Employee(String enm , int eid){
			this.empnm=enm;
			this.empid=eid;	
		}
		
		void displaydata() {
			System.out.println(empnm + " " + empid);
		}
		
	}
	class Dept {
		void Dept1(){
			System.out.println("This is a method");
		}
		
	}
	class HR{
		int hrid=1010;
		void displayhrid() {
			System.out.println(hrid);
		}
		
	}
	
	
public class TestMultiClasses {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee e = new Employee();
		e.displaydata();
		Employee e1 = new Employee("test1",1676);
		e1.displaydata();
		
		Dept d1 = new Dept();
		d1.Dept1();
		
		HR hr1 = new HR();
		hr1.displayhrid();
		
	}

}
