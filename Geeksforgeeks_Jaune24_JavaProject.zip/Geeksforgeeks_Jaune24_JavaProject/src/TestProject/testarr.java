package TestProject;

public class testarr {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int test[] = {1,3,4,5,5,6,7,8,1000,453,299,101};
		
		int sum = 0;
		
		for(int i=0;i<=test.length-1;i++) {
			sum = sum+test[i];
		}
		
		System.out.println(sum);

	}

}
