package TestProject;

import java.util.Scanner;

public class TakeInput {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int EmpId ;
		String EmpName;
		double EmpSal;
		Scanner c = new Scanner(System.in);
		
	    System.out.println("Enter empid:" );
	    EmpId = c.nextInt();
	    System.out.println(EmpId);
	    
	    System.out.println("Enter empname:" );
	    EmpName=c.next();
	    System.out.println(EmpName);

	    
	    System.out.println("Enter empsal:" );
	    EmpSal = c.nextDouble();
	    
	    System.out.println(EmpSal);
	    
	 

}
}