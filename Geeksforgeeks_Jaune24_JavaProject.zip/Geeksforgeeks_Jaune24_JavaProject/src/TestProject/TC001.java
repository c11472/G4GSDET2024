package TestProject;

import java.util.Scanner;

public class TC001 {
	public static void main(String args[]) {
		int arr[] = new int[10];
		Scanner c = new Scanner(System.in);
		int i;
		
		for(i=0;i<=arr.length-1;i++) {
		   arr[i]= c.nextInt();
		}
		for(int j:arr) {
			System.out.println(j+ " ");
			
		}
		
		
	}

}
