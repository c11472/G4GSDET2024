package TestProject;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import dev.failsafe.internal.util.Durations;
import io.opentelemetry.exporter.logging.SystemOutLogRecordExporter;

public class Test101 {
	WebDriver driver;
  @SuppressWarnings("rawtypes")
@Test
  public void method1() {
	  driver = new ChromeDriver();
	 /* driver.get("https://awesomeqa.com/ui/");
	  
      List <WebElement> el = driver.findElements(By.tagName("a"));	
      
      System.out.println(el.size());
	  
      for(int i=0;i<=el.size()-1;i++) {
    	  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1));
    	  String res = el.get(i).getText();
    	  System.out.println(res);
      }*/
	 /* 
	  
	  driver.get("https://katalon-demo-cura.herokuapp.com/");
	  
	  driver.findElement(By.xpath("//*[@id=\"btn-make-appointment\"]")).click();
	  
	  driver.findElement(By.xpath("//*[@id=\"txt-username\"]")).sendKeys("John Doe");
	  driver.findElement(By.xpath("//*[@id=\"txt-password\"]")).sendKeys("ThisIsNotAPassword");
	  driver.findElement(By.xpath("//*[@id=\"btn-login\"]")).click();
	  
	  Select sel = new Select(driver.findElement(By.id("combo_facility")));
	  
	  sel.selectByIndex(2);
	  
	/* List<WebElement> opt=  sel.getOptions();
	 
	 for(int i=0;i<=opt.size()-1;i++) {
		 System.out.println(opt.get(i).getText());
	 }****
	  
	  driver.findElement(By.xpath("//*[@id=\"chk_hospotal_readmission\"]")).click();
	  
	  driver.findElement(By.xpath("//input[@id=\"radio_program_medicaid\"]")).click();
	  //driver.findElement(By.xpath("//input[@id=\"txt_visit_date\"]")).sendKeys("20/08/2024");
	  driver.findElement(By.xpath("//input[@id=\"txt_visit_date\"]")).click();
	  driver.findElement(By.xpath("/html/body/div/div[1]/table/thead/tr[2]/th[3]")).click();
	  driver.findElement(By.xpath("/html/body/div/div[1]/table/tbody/tr[1]/td[7]")).click();
	  driver.findElement(By.name("comment")).sendKeys("This is  a dummy appointment");
	  
	  driver.findElement(By.xpath("//*[@id=\"btn-book-appointment\"]")).click();*/
	  //DragDrop
	  driver.get("https://jqueryui.com/droppable/");
	  Actions act = new Actions(driver);
	  
	  driver.switchTo().frame(0);
	  WebElement el1 = driver.findElement(By.xpath("//*[@id=\"draggable\"]"));
	  WebElement el2 = driver.findElement(By.xpath("//*[@id=\"droppable\"]"));

	  
	  act.dragAndDrop(el1, el2).perform();
	  
  }
}
