package TestProject;

public class DArrayDemo {

	public static void main(String[] args) {
		
		int ids[][] = 
			{{100,22,300,10},{601,789,65,20},{678,67,88,30},
			{101,102,103,104}};
	   int count = 0;
		
		
	 // nested loop
		
		for(int i=0;i<=3;i++) {
			for(int j=0;j<=3;j++) {
				if(ids[i][j]%2!=0) {
					 count =count+1;
					// count++;
					
				}
				
			}
			//System.out.println(count);
			
		}
		
		System.out.println(count);
	
	}
}
