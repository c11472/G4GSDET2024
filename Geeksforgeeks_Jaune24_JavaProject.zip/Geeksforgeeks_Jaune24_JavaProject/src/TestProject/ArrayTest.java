package TestProject;

public class ArrayTest {

	public static void main(String[] args) {
			int arr[] = {12,65,67,57,32,18,14};
			
			int i;
			
			System.out.println(arr.length); // 7
			
			// display the elements
			/* for each
			for(int i:arr) {
				System.out.println(i + " ");
				
				
			}*/
			
			// for loop
			
			
			
			/*for(i=0;i<=arr.length-1;i++) {
				System.out.print(arr[i] + " ");
			}*/
			
			// reverse
			for(i=arr.length-1 ;i>=0;i--) {
				System.out.print(arr[i]+ " ");
			}
			
			
			
			
			
			
			
	}

}
