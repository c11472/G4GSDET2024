package TestProject;

import java.util.Scanner;

public class ArrInp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// take input
		int arr[] = new int[5];
		
		Scanner c = new Scanner(System.in);
		
		for(int i=0;i<=arr.length-1;i++) {
			arr[i] = c.nextInt();
		}
		
		for(int j:arr) {
			System.out.println(j+ " ");
		}
		

	}

}
