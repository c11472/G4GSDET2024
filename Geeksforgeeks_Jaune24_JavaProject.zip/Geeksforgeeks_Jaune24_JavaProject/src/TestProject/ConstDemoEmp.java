package TestProject;

public class ConstDemoEmp {
	String EmpName;
	int empid;
	double sal;
	ConstDemoEmp(){
		 EmpName = "Prachi";
		 empid = 1454;
		  sal = 89786.09;
		
	}
	
	ConstDemoEmp(String enm , int id , double sl){
		this.EmpName=enm;
		this.empid=id;
		this.sal=sl;
	}
	
	public static void main(String args[]) {
		ConstDemoEmp cd = new ConstDemoEmp();
		System.out.println(cd.empid+ " " + cd.EmpName + " "+ cd.sal);
		ConstDemoEmp cd1= new ConstDemoEmp("Gayatri",1147,90887);
		System.out.println(cd1.empid+ " " + cd1.EmpName + " "+ cd1.sal);


		
	}

}
