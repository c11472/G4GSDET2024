package com.login.page1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Login_PF {
	WebDriver driver;
	
	@FindBy(xpath="/html/body/nav/div/div[2]/ul/li[2]/a/span[1]") 
    WebElement MyAcc;
	
	@FindBy(xpath="/html/body/nav/div/div[2]/ul/li[2]/ul/li[2]/a") 
    WebElement Lginopt;

	@FindBy(id="input-email") 
    WebElement textUserName;
	
    //cWebDriver driver;
	
	@FindBy(id="input-password")
	WebElement testPasswod;
	
	@FindBy(xpath="")
	WebElement LoginButton;
	
	public Login_PF(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);		
	}
	
	public void Launch_App() {
		driver.manage().window().maximize();
		driver.get("https://awesomeqa.com/ui");
	}
	
	public void click_myaccount() {
		MyAcc.click();
	}
	
	public void click_loginopt() {
		Lginopt.click();
	}
	
    public void enterusername(String UserName) {
    	textUserName.sendKeys(UserName);
    	
    }
    
    public void enterpassword(String Password) {
    	testPasswod.sendKeys("test123One");
    }
}
