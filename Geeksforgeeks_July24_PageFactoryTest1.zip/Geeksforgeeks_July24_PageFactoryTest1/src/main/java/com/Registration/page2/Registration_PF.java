package com.Registration.page2;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Registration_PF {
	WebDriver driver;
	
	@FindBy(xpath="/html/body/nav/div/div[2]/ul/li[2]/a/span[1]") 
    WebElement Macc;
		
	@FindBy(xpath="//a[contains(text(),'Register')][1]") 
    WebElement regs;
	
	@FindBy(id="input-firstname") 
    WebElement textFirstName;
	
	public Registration_PF(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);	
	}
	
	public void click_myacc() {
		
		Macc.click();
	}
	
	public void click_registeropt() throws InterruptedException {
		Thread.sleep(3000);
		regs.click();
	}
	
	public void Enter_FirstName(String firstnm) {
		textFirstName.sendKeys(firstnm);
		
	}

}
