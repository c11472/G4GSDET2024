package com.sampletest.pgf;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import com.Registration.page2.Registration_PF;
import com.login.page1.Login_PF;

public class Test0001 {
  WebDriver driver= new FirefoxDriver();
  Login_PF lgpf=new Login_PF(driver);
  Registration_PF rgpf = new Registration_PF(driver); 
  Properties p = new Properties();
  @BeforeTest
  public void setup() {
	  driver.get("https://awesomeqa.com/ui");  
  }
  
  @Test(priority=1)
  public void step0() {
	  lgpf.click_myaccount();
	  
  }
  
  @Test(priority=2)
  public void steptest() {
	  lgpf.click_loginopt();
	  
  }
  @Test(priority=3)
  public void step1() throws IOException {
	  FileReader f = new FileReader("./Data/data1.properties");
	  p.load(f);
	  
	  lgpf.enterusername(p.getProperty("name"));
  }
  
  @Test (priority=4)
  public void step2() {
	  lgpf.enterpassword("testuser123");
  }
  
  @Test(priority=5)
  public void clkacc() {
	  rgpf.click_myacc();
	  
  }
  
  @Test(priority=5)
  public void Click_Register() throws InterruptedException {
	  rgpf.click_registeropt();
	  
  }
  
  @Test(priority=6)
  public void firstNamedata() {
	  rgpf.Enter_FirstName("Gayatri");
	  
  }
  
  @AfterTest
  public void teardown() {
	  System.out.println("done");
  }
}
