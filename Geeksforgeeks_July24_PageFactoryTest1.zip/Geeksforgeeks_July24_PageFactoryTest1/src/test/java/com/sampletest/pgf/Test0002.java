package com.sampletest.pgf;

import org.testng.annotations.Test;

public class Test0002 {
  @Test
  public void f() {
  }
}
