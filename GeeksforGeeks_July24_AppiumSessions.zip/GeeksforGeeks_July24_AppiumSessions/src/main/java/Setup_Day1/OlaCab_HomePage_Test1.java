package Setup_Day1;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.remote.MobilePlatform;

public class OlaCab_HomePage_Test1 {

	public static void main(String[] args) throws MalformedURLException {
		
		DesiredCapabilities cap = new DesiredCapabilities();
		cap.setCapability(MobileCapabilityType.PLATFORM_NAME, MobilePlatform.ANDROID);
		cap.setCapability("appPackage", "com.olacabs.customer");
		cap.setCapability("appActivity", "com.olacabs.customer.ui.NewSplashActivity");
		cap.setCapability(MobileCapabilityType.DEVICE_NAME, "EANFWS5HA6IVJN9T");
		AndroidDriver<MobileElement> driver = 
				new AndroidDriver<MobileElement>(new URL("http://127.0.0.1:4723/wd/hub"),
				cap);
		WebDriverWait wait = new WebDriverWait(driver, 10);

		String result = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(
				"/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.view.ViewGroup/android.widget.TextView[2]\r\n")))
				.getText();
		System.out.println(result);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(
				"/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.view.ViewGroup/android.widget.TextView[2]\r\n")))
				.click();
		
		
		
	
		
	}

}
