package componenets;

public class FilePathConfig {

	String testdatap = "./TestData/Inputdata.properties";
	String ValidateData = "./TestData/checkdata.properties";

}
