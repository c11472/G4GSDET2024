package componenets;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Lib1 {
WebDriver wd;

public void init1(WebDriver wd) {
	this.wd = wd;	
}
public void LaunchApp() {
	wd=new FirefoxDriver();
	wd.get("https://www.google.com");
}

}
