package componenets;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.google.common.io.Files;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import junit.framework.Assert;

public class stepsdefinition_testfeature1  {
	// Declare webdriver 

	WebDriver wd;
	
	//Lib1 lib = new Lib1();
	// Declare external resources
	//Declare the file pointer
	FileReader filecheck1;
	Properties p = new Properties();
	Properties p1 = new Properties();
	Properties p2 = new Properties();
	
	FileReader fileloactor;
	

	//FilePathConfig obj = new FilePathConfig();
	//Write a method to init the driver
	public void init(WebDriver wd) {
		this.wd=wd;
		
	}
	
	@Given("The user is in the home page of awesomeqa app")
	//method
	
	public void The_user_is_in_the_home_page_of_awesomeqa_app() throws IOException {
		//define the method
		// automate the step
		System.out.println("Step-1 :" + "Launch Application ");
		wd = new FirefoxDriver();
		wd.get("https://awesomeqa.com/ui/");
		// Assert a step
		
		filecheck1= new FileReader("./TestData/checkdata.properties");
		String PageTitle = wd.getTitle();
		p.load(filecheck1);
		String expdata = p.getProperty("PageTitle1");
		
		//Assert 
		Assert.assertEquals(PageTitle, PageTitle);
		//lib.LaunchApp();
		
	}
	

	@When("The user clicks on My Account")
	//method
	public void The_user_clicks_on_My_Account() throws IOException {
		
		fileloactor = new FileReader("./LocatorsInfo/Module1Locators.properties");
		p2.load(fileloactor);
		System.out.println("Step-2 :" + "Click on My Account ");
		//wd.findElement(By.xpath("//span[contains(text(),'My Account')]")).click();
		wd.findElement(By.xpath(p2.getProperty("myac"))).click();

		
	}
	
	
	@When("The user clicks on register")
	//method
	public void The_user_clicks_on_register() {
		wd.findElement(By.xpath("//a[contains(text(),'Register')]")).click();
		
	}
	
	
	@When("The user enters first name")
	//method
	public void The_user_enters_first_name() throws IOException {
		//Maintain the test data in external file
		FileReader f1= new FileReader("./TestData/Inputdata.properties");
		p1.load(f1);
		wd.findElement(By.xpath("//input[@name='firstname']")).sendKeys(p1.getProperty("fnm"));
		
	}
	
	@When("The user enters last name")
	//method
	public void The_user_enters_last_name() {
		wd.findElement(By.xpath("//input[@name='lastname']")).sendKeys(p1.getProperty("lnm"));
		
	}
	@When("The user enters email")
	//method
	public void The_user_enters_email() throws IOException {
		FileReader f1 = new FileReader("./TestData/Inputdata.properties");
		p1.load(f1);
		wd.findElement(By.xpath("//input[@name='email']")).sendKeys(p1.getProperty("em"));
		
	}
	@And("The user clicks on register button")
	//method
	public void The_user_clicks_on_register_button() {
		wd.findElement(By.xpath("//input[@type=\"submit\"]")).click();

		
	}
	@Then("The user must get Registration successful message")
	//method
	public void The_user_must_get_Registration_successful_message() throws IOException {
		//wd.findElement(By.xpath("//input[@type=\"submit\"]"));
		System.out.println("Incomplete");
		String val=wd.findElement(By.xpath("/html/body/div[2]/div[1]")).getText();
		System.out.println(val);
		
		 // Capture screen image
		 File src = ((TakesScreenshot) wd).getScreenshotAs(OutputType.FILE);
	     Files.copy(src, new File("./Screenshots/regsfunction.png"));

	}

}
