package componenets;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class stepsdefinition_testfeature2 {
	
	WebDriver wd;
	@Given("The user is in home page of google")
	public void Launch_Google() {
		wd = new FirefoxDriver();
		wd.get("https://www.google.com");
		
	}
	@When("The user enters the search string")
	public void Enter_SearchString() {
		
		wd.findElement(By.name("q")).sendKeys("test data");
		
		
	}
	

}
