package componenets;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class stepsdefinition_testfeature2tag3 {
	WebDriver wd;
	//Lib1 l1 = new Lib1();
	
	@Given("The user is in firefox browser")
	public void The_user_is_in_firefox_browser() {
		//l1.init1(wd);
		//l1.LaunchApp();
		wd = new FirefoxDriver();
		wd.get("https://www.google.com");
		
		
		
		
	}
	
	
	@When("The user enters the url and click on enter")
	public void dummym1() {
		System.out.println("Hello");
		
	}
	@Then("The user should be able to view google home page")
	public void dummym2() {
		System.out.println("Hello world !");
		
	}

	

}
