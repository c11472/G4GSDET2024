package componenets;
import static org.junit.Assert.*;
import org.junit.Test;
import org.junit.runner.RunWith;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
features="src\\test\\java\\componenets", 
glue={"componenets"},
monochrome=true,
plugin={"pretty","html:target/HtmlReports/firstexecution.html"},
tags= "@tag1 or @tag2 or @tag3 "
)


public class sampledonotexecute {

}
