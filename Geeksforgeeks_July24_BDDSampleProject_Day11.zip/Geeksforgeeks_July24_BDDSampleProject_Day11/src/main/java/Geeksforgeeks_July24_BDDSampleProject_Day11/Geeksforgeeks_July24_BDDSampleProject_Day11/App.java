package Geeksforgeeks_July24_BDDSampleProject_Day11.Geeksforgeeks_July24_BDDSampleProject_Day11;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
