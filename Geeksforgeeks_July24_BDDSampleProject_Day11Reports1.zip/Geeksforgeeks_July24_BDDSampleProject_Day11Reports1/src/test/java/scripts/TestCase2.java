package scripts;

import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

public class TestCase2  extends ExtentBase{
  @Test(priority=3)
  public void f1() {
	  test.log(Status.PASS, "Pass test step 3");
  }
  
  @Test(priority=4)
  public void f2() {
	  test.log(Status.PASS, "Pass test step 4");
  }
  
}
