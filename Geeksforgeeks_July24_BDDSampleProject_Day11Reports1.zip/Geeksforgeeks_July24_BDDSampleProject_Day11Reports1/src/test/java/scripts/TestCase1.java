package scripts;

import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

public class TestCase1  extends ExtentBase{
  @Test(priority=1)
  public void s1() {
	  test.log(Status.PASS, "Step-1 is pass");
  }
  
  @Test(priority=2)
  public void s2() {
	  test.log(Status.PASS, "Step-2 is passed");
  }
}
