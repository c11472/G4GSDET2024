package Geeksforgeeks_July24_BDDSampleProject_Day11Reports1.Geeksforgeeks_July24_BDDSampleProject_Day11Reports1;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
