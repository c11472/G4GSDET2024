package com.sample.pgtest;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class TC01_PGTest {
	 WebDriver driver = new ChromeDriver();
	 @FindBy(xpath="/html/body/div[2]/div/div/form/fieldset[1]/div[2]/div/input")  WebElement el;
	 
	    public void LoginPage(WebDriver driver) {
	        PageFactory.initElements(driver, this);
	    }
 public void launchapp() {
		 driver.get("https://awesomeqa.com/ui/index.php?route=account/register");
	 }
	 
	
	 
	 public void dataentry1(WebElement el) {
		 this.el=el;
		 el.sendKeys("Test data first name");
	 }


}


