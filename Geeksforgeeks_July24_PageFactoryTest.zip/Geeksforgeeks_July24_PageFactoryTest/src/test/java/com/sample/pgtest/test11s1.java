package com.sample.pgtest;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class test11s1 {
	WebDriver driver; 
	
	TC01_PGTest obj = new TC01_PGTest();
	WebElement el;
  @Test(priority=1)
  public void f() {
	  obj.LoginPage(driver);
	  obj.launchapp();
	  //obj.enter_firstname();
  }
  @Test(priority=2)
  public void f1(WebElement el) {
	  this.el=el;
	  obj.dataentry1(el);
  }
}
