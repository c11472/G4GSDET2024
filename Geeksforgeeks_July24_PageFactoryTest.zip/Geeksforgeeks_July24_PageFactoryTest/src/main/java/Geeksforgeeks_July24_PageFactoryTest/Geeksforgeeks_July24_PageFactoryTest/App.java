package Geeksforgeeks_July24_PageFactoryTest.Geeksforgeeks_July24_PageFactoryTest;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
