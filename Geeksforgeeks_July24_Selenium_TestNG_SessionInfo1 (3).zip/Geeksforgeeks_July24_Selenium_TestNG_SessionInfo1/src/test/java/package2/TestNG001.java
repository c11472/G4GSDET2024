package package2;

import org.testng.annotations.Test;

public class TestNG001 {
	@Test
	public void method1() {
		System.out.println("test12");
		
	}
	@Test
	public void method2() {
		System.out.println("Test14");
		
	}

}
