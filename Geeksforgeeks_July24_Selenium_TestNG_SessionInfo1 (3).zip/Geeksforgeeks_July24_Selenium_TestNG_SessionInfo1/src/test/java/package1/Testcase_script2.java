package package1;

import org.testng.annotations.Test;

public class Testcase_script2 {
  @Test
  public void f() {
	  System.out.println("Hello JDBC-SQL !");
  }
}
