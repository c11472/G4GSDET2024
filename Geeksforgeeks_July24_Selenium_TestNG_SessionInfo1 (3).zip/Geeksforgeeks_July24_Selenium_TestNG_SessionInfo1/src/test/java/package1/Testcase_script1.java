package package1;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Testcase_script1 {
@BeforeSuite

public void suiteafterxecution() {
	System.out.println("suite before");
	  
}


@BeforeTest
public void preconditionstep() {
	System.out.println("Open eclipse IDE and access the class in respective package ");
	
}

  @Test // default annotation
  public void function_one() {
	  //assigned with task 
	  // Reverse a string
	  
	  String res = "Hello TestNG 7.10";
	  StringBuffer sb = new StringBuffer(res);
	  System.out.println(sb.reverse());
  }
  
  @Test(priority=3)
  public void function_two() {
	  //reverse the array
	  int arr[] = {1,2,3,4,5,6,7};
	  int i;
	  for(i=arr.length-1;i>=0;i--) {
		  System.out.println(arr[i] );
	  }
	  
  }
  @Test(priority=1)
  public void function_three() {
	  // display done
	  System.out.println("done !");
	  
  }
  @AfterTest
  public void postconditionstep() {
	  
	  System.out.println("Check the console logs or reports");
	  
  }
  
  @AfterSuite
  public void suitebeforexecution() {
	  System.out.println("suite after");
	  
  }
  
  
}
