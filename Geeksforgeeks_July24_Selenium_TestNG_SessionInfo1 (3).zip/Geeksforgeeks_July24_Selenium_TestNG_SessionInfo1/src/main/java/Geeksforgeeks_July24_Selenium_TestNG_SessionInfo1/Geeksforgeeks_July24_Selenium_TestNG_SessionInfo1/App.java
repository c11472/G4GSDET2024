package Geeksforgeeks_July24_Selenium_TestNG_SessionInfo1.Geeksforgeeks_July24_Selenium_TestNG_SessionInfo1;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
