package Library_Data;


import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ExceptionHandleDemo {
	public static void main(String args[]) {
		WebDriver wd = new ChromeDriver();
		wd.get("https://www.awesomeqa.com/ui");
		
		
		try {
			String S=wd.findElement(By.id("123")).getText();
			System.out.println(S);
		}
		catch(NoSuchElementException e) {
			System.out.println("No such element present");
		}
		catch(ElementNotInteractableException e1) {
			System.out.println(e1.getStackTrace());
		}
		
		
	}

}
