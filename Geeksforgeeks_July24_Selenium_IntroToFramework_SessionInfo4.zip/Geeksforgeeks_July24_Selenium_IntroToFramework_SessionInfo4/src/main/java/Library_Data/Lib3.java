package Library_Data;

public class Lib3 {
	
	public void samplemethod() {
		int arr[] = {1,2,3,4,5};
		for(int i:arr) {
			System.out.print(i + " ");
		}
	}

}
