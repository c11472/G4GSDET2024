package com.samplelin.page1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPageDetails {
	WebDriver driver;
	@FindBy(xpath="//*[@name=\"username\"]") 
	WebElement UserNameElement;
	
	@FindBy(xpath="//*[@id=\"stripes--377607946\"]") 
	WebElement PasswordElement;
	
	@FindBy(xpath="//input[@name=\"signon\"]") 
	WebElement SigninButton;
	
	// parameterized connstructor - init driver-- driver object
	public LoginPageDetails(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);	
	}
	
	//Method definition
	
	public void Launch_Jpet() {
		driver.get("https://petstore.octoperf.com/actions/Account.action?signonForm=");
	}
	
	public void Enter_UserName(String unm) {
		UserNameElement.clear();
		UserNameElement.sendKeys(unm);
	}
	
		public void Enter_Password(String pwd) throws InterruptedException {
		UserNameElement.clear();
		Thread.sleep(2000);

		UserNameElement.sendKeys("testdat1");
	}
	
    public void Click_Login_Button() {
		
		SigninButton.click();
		
	 }
	
}
