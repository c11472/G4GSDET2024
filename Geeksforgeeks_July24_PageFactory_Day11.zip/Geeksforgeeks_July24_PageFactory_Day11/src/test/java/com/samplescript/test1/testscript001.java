package com.samplescript.test1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.samplelin.page1.LoginPageDetails;

public class testscript001 {
  // Basic congfig
	
	WebDriver driver = new FirefoxDriver();
	LoginPageDetails page1 = new LoginPageDetails(driver);
	
	 ExtentReports ext1; // class 
	  ExtentTest test;//interface
	 
  @BeforeTest
  public void presetup() {
	  
	  ExtentHtmlReporter testreport = new ExtentHtmlReporter("./HtmlReports/testreport1.html");
	  ext1=new ExtentReports();
	  ext1.attachReporter(testreport);
	  test = ext1.createTest("user.dir", "test");

	  
  }
	
  @Test(priority=1)
  public void Launch_Jpet_App() {
	  
	  page1.Launch_Jpet();
	  page1.Enter_UserName("testuser1");
	  test.log(Status.PASS, "App invoked");
	  
  }
  
  @Test(priority=2)
  
  public void Enter_UserName_Input() {
	  
      page1.Enter_UserName("testdata1");	
      test.log(Status.PASS, "User input - done");
  }
  
  @AfterTest
  public void teardown() {
	  ext1.flush();//
	  ext1.close();//
	  
  }
}
